#include "Localization.h"


//==================================================================
//========================================================================================= Class constructor ========================================================================
//================================================================== 


Localization::Localization(uint8_t MotorRight_pin_F, uint8_t MotorRight_pin_B, uint8_t MotorRight_Enable, uint8_t MotorLeft_pin_F, uint8_t MotorLeft_pin_B, uint8_t MotorLeft_Enable){
  
// ===========  Motor variables init ===================================

        _MotorRight_pin_F=MotorRight_pin_F;
	_MotorRight_pin_B=MotorRight_pin_B;
	_MotorRight_Enable=MotorRight_Enable;
	_MotorLeft_pin_F=MotorLeft_pin_F;
	_MotorLeft_pin_B=MotorLeft_pin_B;
	_MotorLeft_Enable=MotorLeft_Enable;
	
	pinMode(_MotorRight_pin_F,OUTPUT);
	pinMode(_MotorRight_pin_B,OUTPUT);
	pinMode(_MotorRight_Enable,OUTPUT);
	pinMode(_MotorLeft_pin_F,OUTPUT);
	pinMode(_MotorLeft_pin_B,OUTPUT);
	pinMode(_MotorLeft_Enable,OUTPUT);

//==========  Movement controlling variables =========================
	rightDeviation=false;
	leftDeviation=false;
	controllerTick=0;
	delayTime=0;
	speedLeft=MAX_MOTOR_SPEED_RUN;
	speedRight=MAX_MOTOR_SPEED_RUN;
	delayState=false;
	controllerGain=CONTROLLER_GAIN;// --------------------------------------------------------------------------------------------------------------***
	functionState=false;
    
 }  
 
 
//=================== Motor movement functions ============================
//Move forward with specified speed Or full speed if parameters not provided
void Localization::moveForward(uint8_t speedRight, uint8_t speedLeft){
	analogWrite(_MotorRight_Enable,speedRight);
	analogWrite(_MotorLeft_Enable,speedLeft);
	digitalWrite(_MotorRight_pin_F,HIGH);
	digitalWrite(_MotorRight_pin_B,LOW);
	digitalWrite(_MotorLeft_pin_F,HIGH);
	digitalWrite(_MotorLeft_pin_B,LOW);
	
}
//Move backward with specified speed Or full speed if parameters not provided
void Localization::moveBackward(uint8_t speedRight, uint8_t speedLeft){
	analogWrite(_MotorRight_Enable,speedRight);
	analogWrite(_MotorLeft_Enable,speedLeft);
	digitalWrite(_MotorRight_pin_F,LOW);
	digitalWrite(_MotorRight_pin_B,HIGH);
	digitalWrite(_MotorLeft_pin_F,LOW);
	digitalWrite(_MotorLeft_pin_B,HIGH);
}
void Localization::turnLeft(uint8_t speedRight){
	analogWrite(_MotorRight_Enable,speedRight);
	analogWrite(_MotorLeft_Enable,0);
	digitalWrite(_MotorRight_pin_F,HIGH);
	digitalWrite(_MotorRight_pin_B,LOW);
	digitalWrite(_MotorLeft_pin_F,LOW);
	digitalWrite(_MotorLeft_pin_B,LOW);
}
void Localization::turnRight(uint8_t speedLeft){
	analogWrite(_MotorRight_Enable,0);
	analogWrite(_MotorLeft_Enable,speedLeft);
	digitalWrite(_MotorRight_pin_F,LOW);
	digitalWrite(_MotorRight_pin_B,LOW);
	digitalWrite(_MotorLeft_pin_F,HIGH);
	digitalWrite(_MotorLeft_pin_B,LOW);
}
void Localization::turnLeftInPlace(uint8_t speedRight, uint8_t speedLeft){
	analogWrite(_MotorRight_Enable,speedRight);
	analogWrite(_MotorLeft_Enable,speedLeft);
	digitalWrite(_MotorRight_pin_F,HIGH);
	digitalWrite(_MotorRight_pin_B,LOW);
	digitalWrite(_MotorLeft_pin_F,LOW);
	digitalWrite(_MotorLeft_pin_B,HIGH);
}
void Localization::turnRightInPlace(uint8_t speedRight, uint8_t speedLeft){
	analogWrite(_MotorRight_Enable,speedRight);
	analogWrite(_MotorLeft_Enable,speedLeft);
	digitalWrite(_MotorRight_pin_F,LOW);
	digitalWrite(_MotorRight_pin_B,HIGH);
	digitalWrite(_MotorLeft_pin_F,HIGH);
	digitalWrite(_MotorLeft_pin_B,LOW);
}
void Localization::stop(){
	analogWrite(_MotorRight_Enable,0);
	analogWrite(_MotorLeft_Enable,0);
	digitalWrite(_MotorRight_pin_F,LOW);
	digitalWrite(_MotorRight_pin_B,LOW);
	digitalWrite(_MotorLeft_pin_F,LOW);
	digitalWrite(_MotorLeft_pin_B,LOW);
}

//============= Robot straight movement function ==========================

void Localization::speedController(boolean rightDeviation, boolean leftDeviation, float headingDiff){
headingDiff=abs(headingDiff);
if(delayTime<millis()) delayState=false;
if(headingDiff >= ERROR_BAND || delayState){     
    if(rightDeviation){
      if(!delayState){
        moveForward(speedRight,0);
        delayTime=10+millis();
        delayState=true; 
        return;    
      }      
    }
   if(leftDeviation){
      if(!delayState){
        moveForward(0,speedLeft);
        delayTime=10+millis();       //-----------------------------?5?
        delayState=true; 
        return;    
      }      
    }    
  }else  moveForward(speedRight,speedLeft);
}

void Localization::courseCorrection( float currentHeading, float targetHeading){
  
  float headingDiff=targetHeading-currentHeading;
  headingDiff=abs(headingDiff);
  if(headingDiff > (360-headingDiff) && targetHeading > currentHeading){
    //yaw has crossed 0 - 360 degree 
    //and deviating to left
    headingDiff=(360-headingDiff);
    rightDeviation=false;
    leftDeviation=true;
  }else if(headingDiff > (360-headingDiff) && targetHeading < currentHeading){
    //yaw has crossed 0 - 360 degree 
    //and deviating to right
    headingDiff=(360-headingDiff);
    rightDeviation=true;
    leftDeviation=false;
  }else if(targetHeading > currentHeading){
    //Left deviation
    rightDeviation=false;
    leftDeviation=true;
  }else if(targetHeading < currentHeading){
    //Right deviation
    rightDeviation=true;
    leftDeviation=false;
  }
  speedController(rightDeviation,leftDeviation,headingDiff); 
}
//==================== Right Turn function ======================================

//==================== Localization function  ===================================

bool Localization::moveStraight(uint16_t tempCount, uint16_t distanceCount ,float heading, float targetHeading){
     if(tempCount<(distanceCount-ERROR_MOVE_AFTER_STOP)){
         courseCorrection(heading,targetHeading);
         return false;//function not completed
     }else{
          stop();//stop the motors
          return true;//action completed
     }
	
}
bool Localization::turn(boolean directionFlag, float currentHeading, float targetHeading){
      float headingDiff=targetHeading-currentHeading;
    headingDiff=abs(headingDiff);
    if(headingDiff > (360-headingDiff) && targetHeading > currentHeading){
      //yaw has crossed 0 - 360 degree 
      //and deviating to left
      headingDiff=(360-headingDiff);

    }else if(headingDiff > (360-headingDiff) && targetHeading < currentHeading){
      //yaw has crossed 0 - 360 degree 
      //and deviating to right
      headingDiff=(360-headingDiff);
    }
  
       //  if( currentHeading < (targetHeading+ERROR_IN_TURN) && currentHeading > (targetHeading-ERROR_IN_TURN)){-------------------------------------------------------------------***
    

    
    if(headingDiff<ERROR_IN_TURN ){   //-----------------------------------333333333333333333333-----Origional is  less than   but   i put greater than 3333333333333333--***
         stop();//stop the motors
         return true;
       }else{
         if(directionFlag){//turn right
                turnRightInPlace(MAX_MOTOR_SPEED_TURN,MAX_MOTOR_SPEED_TURN);// speed may be adjusted upto max 255 for both motors        ------------?6? سرعة الموتور
         }else{//turn left
                turnLeftInPlace(MAX_MOTOR_SPEED_TURN,MAX_MOTOR_SPEED_TURN);// speed may be adjusted upto max 255 for both motors based on performance
         }
         return false; // not reached the target keep turning
       }
     
}
