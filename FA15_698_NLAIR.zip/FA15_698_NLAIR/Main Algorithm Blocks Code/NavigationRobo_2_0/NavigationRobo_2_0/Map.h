#ifndef Map_h
#define Map_h
#include <Arduino.h>

#define NORTH 0
#define EAST 1
#define SOUTH 2
#define WEST 3

//We will define block widths. so that by measuring block width we can identify in which block we are in.
//block widths are in centimeters
//block 1 starts from grid (1,1) to (17,3)
#define BLOCK_1_WIDTH 240     // -------------------------------------------------------------------it was 535 now only 9 grids =270
#define BLOCK_1_LENGTH 90     //   Currently not used, so their value doesn't affect the program
#define BLOCK_1_X_MIN 1
#define BLOCK_1_Y_MIN 1 
#define BLOCK_1_X_MAX 8   // ---------------------------------origional value was 19 or 18  now for test 9
#define BLOCK_1_Y_MAX 3      // it was 4 

#define BLOCK_2_WIDTH 180// -------------------------------------------------------------------it was 571 now ..150   5 grids..
#define BLOCK_2_LENGTH 120    //Currently not used, so their value doesn't affect the program
#define BLOCK_2_X_MIN 1      // it was  1  but for test   4
#define BLOCK_2_Y_MIN 4 
#define BLOCK_2_X_MAX 6  // ---------------------------------origional value was 19  now for test 
#define BLOCK_2_Y_MAX 7

#define BLOCK_3_WIDTH 240
#define BLOCK_3_LENGTH 170//Currently not used, so their value doesn't affect the program
#define BLOCK_3_X_MIN 1
#define BLOCK_3_Y_MIN 8 
#define BLOCK_3_X_MAX 8
#define BLOCK_3_Y_MAX 14

#define BLOCK_4_WIDTH 210
#define BLOCK_4_LENGTH 26//Currently not used, so their value doesn't affect the program
#define BLOCK_4_X_MIN 1
#define BLOCK_4_Y_MIN 15 // was 9
#define BLOCK_4_X_MAX 7 // was 8
#define BLOCK_4_Y_MAX 21// was 21

#define BLOCK_5_WIDTH 210
#define BLOCK_5_LENGTH 401//Currently not used, so their value doesn't affect the program
#define BLOCK_5_X_MIN 1
#define BLOCK_5_Y_MIN 22 // was 22
#define BLOCK_5_X_MAX 7 // was 12
#define BLOCK_5_Y_MAX 28 // was 28

#define BLOCK_6_WIDTH 210
#define BLOCK_6_LENGTH 401//Currently not used, so their value doesn't affect the program
#define BLOCK_6_X_MIN 1
#define BLOCK_6_Y_MIN 29  // was 29
#define BLOCK_6_X_MAX 7  // was 12
#define BLOCK_6_Y_MAX 35  // was 35

#define WIDTH_OFFSET 0
#define LENGTH_OFFSET 1
#define X_MIN_OFFSET 2
#define Y_MIN_OFFSET 3
#define X_MAX_OFFSET 4
#define Y_MAX_OFFSET 5
#define INDEX_OFFSET 6
//implemented blocks number. must be updated when new block is added.
#define BLOCKS_NUM 6

//--------------------------------------------------------------------allowed Error in the block width detection. Can be changed for experiments
#define ERROR_IN_WIDTH 20 // --------------was 20 now 30---------------------------Width error allowed error------------- now 6

#define GRID_LENGTH_CM 30

 //#define GRID_LENGTH 11                            //count of the grid length. 11 for 30 cm, 8 for 20 cm approx
#define GRID_LENGTH 8         //count of the grid length. 7 or 8 maybe for 30 cm, maybe 5  for 20 cm approx         it was 11  then 7  then 1 now 3 ------------- كم تقطع لفة الكفرة  من سم



class Map {
  
  public:
    //-----------------------Some global variables
    
    int error_coordX=0;
    uint16_t estimated_coordX;
    uint16_t estimated_coordY;
    
      struct GridSquare {
      uint16_t coordX;
      uint16_t coordY;
      boolean obstacleFlag;
            float headingAngle;
      uint8_t direction;
      
    } nextGrid,currentGrid,eastGrid,westGrid,northGrid,southGrid;

    //---------------------------------------------------------------------------------------------Block data structure------------------------------------------------------------***
    struct block {
      uint16_t width;
      uint16_t height;
      uint16_t min_coordX;
      uint16_t min_coordY;
      uint16_t max_coordX;
      uint16_t max_coordY;
      uint16_t block_index;
    };
    //Block 1 data . It is saved in program memory. PROGMEM is used to do it
    const block block_1 PROGMEM ={
      BLOCK_1_WIDTH,
      BLOCK_1_LENGTH,
      BLOCK_1_X_MIN,
            BLOCK_1_Y_MIN,
      BLOCK_1_X_MAX,
      BLOCK_1_Y_MAX,
      1  //block index no. for block 1 its 1 and so on
    };
    
    const block block_2 PROGMEM ={
      BLOCK_2_WIDTH,
      BLOCK_2_LENGTH,
      BLOCK_2_X_MIN,
            BLOCK_2_Y_MIN,
      BLOCK_2_X_MAX,
      BLOCK_2_Y_MAX,
      2
    };
    
    const block block_3 PROGMEM ={
      BLOCK_3_WIDTH,
      BLOCK_3_LENGTH,
      BLOCK_3_X_MIN,
            BLOCK_3_Y_MIN,
      BLOCK_3_X_MAX,
      BLOCK_3_Y_MAX,
      3
    };
    
    const block block_4 PROGMEM ={
      BLOCK_4_WIDTH,
      BLOCK_4_LENGTH,
      BLOCK_4_X_MIN,
            BLOCK_4_Y_MIN,
      BLOCK_4_X_MAX,
      BLOCK_4_Y_MAX,
      4
    };
    
    const block block_5 PROGMEM ={
      BLOCK_5_WIDTH,
      BLOCK_5_LENGTH,
      BLOCK_5_X_MIN,
            BLOCK_5_Y_MIN,
      BLOCK_5_X_MAX,
      BLOCK_5_Y_MAX,
      5
    };
    
    const block block_6 PROGMEM ={
      BLOCK_6_WIDTH,
      BLOCK_6_LENGTH,
      BLOCK_6_X_MIN,
            BLOCK_6_Y_MIN,
      BLOCK_6_X_MAX,
      BLOCK_6_Y_MAX,
      6
    };
    
    //-----------------------------------------------------------------------------------------Array of grids which have--------------------------------------------------------
    
    void initialize(uint16_t x=1, uint16_t y=1){//----------------------------------------------------default start is 1,1      -------------------------------------------grid (1,1)
      currentGrid.coordX = x;
      currentGrid.coordY = y; 
      
      // We will always start from direction north         -----------------------
      //means whatever will be the front of the robot that will be treated as front

      
      currentGrid.direction= NORTH;
      
      eastGrid.direction= EAST;
      westGrid.direction= WEST;
      northGrid.direction= NORTH;
      southGrid.direction= SOUTH;
      
      //now update the coordinated of neighbours
      generateNeighbours();
    }
                 
    boolean generateNeighbours(){   //-----------------------------------------------------------------------------------------------------------Neighbours--------------------***
      
      //using current coordinates to generate coordinates of neighbours
      //because we are using kind of dynamic map.
      
                        //Update south grid         ------------------------------------------------------------------------------------------
                        if(currentGrid.coordY < 2) southGrid.coordY =0;
                        else southGrid.coordY = currentGrid.coordY-1;
                        southGrid.coordX = currentGrid.coordX;
                        
                        //update north grid
                        northGrid.coordX = currentGrid.coordX;
                        northGrid.coordY = currentGrid.coordY+1;
                        
                        //update west grid
                        if(currentGrid.coordX < 2) westGrid.coordX =0;
                        else westGrid.coordX = currentGrid.coordX-1;
                        westGrid.coordY = currentGrid.coordY;
                        
                        //update east grid
                        eastGrid.coordX = currentGrid.coordX+1;
                        eastGrid.coordY = currentGrid.coordY;    
                        
      return true;
    }
    
    //This function takes measuremet from ultrasonic sensor, which are distances from left wall and right walls
    // To identify the block we use its width if the width is same as saved then that block is identified
    // Identification starts from first checking the block as measured by encoders. If not then we check
    // one block above and one block below the encoder measured block  ---------------------------------------------------------------------------------------------Estimate position-***
    
  int estimatePosition(int leftWallDist, int rightWallDist, uint16_t coordX, uint16_t coordY){
      int block_no = currentBlock(coordX, coordY);
      Serial.println("   Detected block no  ");
      Serial.println(block_no);
      int estimated_block=0;
      
      if(block_no==0) return -1;//--------------------------------------------------------------------error occured in searching block-------------------------------     -1
      
      int block_width_measured = leftWallDist+rightWallDist;
      if(abs(block_width_measured - blocks[block_no-1]->width) < ERROR_IN_WIDTH){
        
        //-----------------------------------------------We are in the same block as measured by encoders . Now we will search for correct grid inside this block
        estimated_block = block_no;
      }
      //-------------------------------------------------We are not in the same block as measured by encoders. 
      //-------------------------------------------------So we will try one block up and one block down if available
      
      else{
        if(block_no+1 <= BLOCKS_NUM){//------------------We are not in the last block so we can check whether we are in next block.
          if(abs(block_width_measured -blocks[block_no]->width) < ERROR_IN_WIDTH){
            
            //-------------------------------------------We are in the block just above the encoder measured block. 
            
            estimated_block = block_no+1;//--------------one block above 
          }
        }
        if(block_no-1 >= 1){//We are in the first block so we can check wheather we are in block down
            //Since block_no starts from 1(ie block number one), we need to convert it to blocks array index, which starts from 0. ie one less. and we 
          //want to access one below block, so one less . hence -2
          if(abs(block_width_measured - blocks[block_no-2]->width) < ERROR_IN_WIDTH){ 
            //We are in the block just below the encoder measured block.
            estimated_block = block_no-1;
          } 
        } 
      }
        
      if(estimated_block==0) return -2;//---------------------------------------------------------Estimating error inside the block ----------------------------------------    -2
      
      
      //*************************************************************  Estimating of X axis coordinate*********************************************************************************
      
      //min x coordinate of the block plus distance from left wall divided by grid length. This gives actual x coordinate------------------------------ how to know where you are in grid
      
       estimated_coordX = blocks[estimated_block-1]->min_coordX + (uint16_t)(leftWallDist/GRID_LENGTH_CM);
       
       //Error in X axis coordinate 
       
       error_coordX = estimated_coordX - currentGrid.coordX;
       
       //---------------------------------------------------****************estimating y coordinate********************-----------------------------------------------
       
       //Since we didn't have any wall in y aixs. So estimating y is not possible accurately
       // We can only check wheater we are out by one block
       
       if(estimated_block != block_no){
         //----------------If we are out of one block then we are assuming same error in Y axis as in X axis coordinate
         
        estimated_coordY = currentGrid.coordY+error_coordX;
        //-----------------If y coordinate, after adding the error in X is going beyond the estimated block
        //-----------------Then we will keep the encoder measured coordinate
        
        if(estimated_coordY < blocks[estimated_block-1]->min_coordY || estimated_coordY > blocks[estimated_block-1]->max_coordY){  //-------------------------------***
          estimated_coordY = currentGrid.coordY;
        }
       }else{
       estimated_coordY = currentGrid.coordY;
       }
      return 0;
    }
    
  private:
     
      //----------------------------------------------------------------------------------------------pointer to the blocks are stored in an array. any new block must be added here--*** 
      
    const block* blocks[BLOCKS_NUM] ={&block_1, &block_2, &block_3, &block_4, &block_5, &block_6};
    
    
    //------------------------------------------------------------------------------------------- This function decides in which block we should be according to the encoder measurement
      int currentBlock(uint16_t x, uint16_t y){
      // going over blocks starting from 1
      
      for (int i=0 ;i<BLOCKS_NUM; i++){
    Serial.println("  Min X and Min Y ");
    Serial.print(blocks[i]->min_coordX);
    Serial.print(" ");
    
    Serial.println(blocks[i]->max_coordY);
        if(x>=blocks[i]->min_coordX && y>=blocks[i]->min_coordY && x<=blocks[i]->max_coordX && y<=blocks[i]->max_coordY){
           return (i+1);//-----------------------------------------------------------------return block number.Since array index starts from 0, we are adding 1 to make it block number
         }  
      }
      return 0;//we are out of defined blocks
    }
};
#endif

// how  to count    grids    10 bytes   at a time 
/*
 * 
 * 1 float =  4 byte
1 uint16_t = 2 byte
1 uint8_t = 1byte
1 boolean = 1 byte

 struct GridSquare {
            uint16_t coordX; = 2 byte
            uint16_t coordY; = 2 byte
            boolean obstacleFlag; = 1 byte
                        float headingAngle; =4 byte
            uint8_t direction; = 1 byte
        } nextGrid,currentGrid,....

total 2+2+1+4+1 = 10 * 5 because we count current +4 neighboors=5     total =50 bytes at a time
 * 
 *
 */

