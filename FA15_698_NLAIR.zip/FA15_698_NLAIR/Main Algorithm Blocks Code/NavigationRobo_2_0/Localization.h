#include <Arduino.h>
//#define ONE_GRID 30 // one grid is 30x30cm
 //one revolution is 21.5cm and 8 holes in the wheel, means 8 counts                                                                             هذه الصفحة لمتغيرات الموتور والدوال الخاصة 
 // so per 30 cm grid 30/(21.5/8) = 11.162 approx 11 counts
 //---------------------------------------------------------------------------------------
 // if we use the tire with 5 holes means     per 30 cm grid    30/(21.5/5)"=4.3"   then  30/4.3= 6.976744186           in 20 cm     20/4.3= 4.65116
 //---------------------------------------------------------------------------------------
//#define COUNT_PER_GRID 11

#define CONTROLLER_DELTA_T 5 //controller delta t
#define CONTROLLER_GAIN 5    //Controller gain
#define MAG_DELTA 5          //magnetometer delta t
#define ERROR_BAND 1         //error band in degrees

// to compensate error due to inertia of robo
//it will move some small distance after even after "stop()" exacuted

#define ERROR_MOVE_AFTER_STOP 1

//Adjust this value if robo is getting lost while taking turn.increase it in steps of 0.5
#define ERROR_IN_TURN  3 //------------------------------------------------------------------------------------Earlier .8 //error in turn. in degree  now to 3 or 1  it was 2

#define ANGLE_90 3  // wheel count for turn ----------------------------------------------------------------------------- عملية الدوران قد تحتاج تغيير عدد فتحات الكفر
#define ANGLE_180 5 // wheel count for turn -----------------------------------------------------------------------------   it was 5   now   6

#define MAX_MOTOR_SPEED_TURN 100         // it was 160 ------------------ سرعة المحرك
#define MAX_MOTOR_SPEED_RUN 120          // it was 160 


// =============================================================================================================================================================================== --***

class Localization {
    public:
    
    Localization(uint8_t MotorRight_pin_F, uint8_t MotorRight_pin_B, uint8_t MotorRight_Enable, uint8_t MotorLeft_pin_F, uint8_t MotorLeft_pin_B, uint8_t MotorLeft_Enable);
//=================================================================
//===      Variables for robot navigation              ============
//=================================================================
	boolean rightDeviation;
	boolean leftDeviation;
	unsigned long controllerTick;
	unsigned long delayTime;
	
	uint8_t speedLeft;
	uint8_t speedRight;
	bool delayState;
	uint8_t controllerGain;  //-----------------------------------------------------------------------------------------------------------------------------------------------------------***
	bool functionState;

//=======================================================================
//===================  Motor variables  =================================
//=======================================================================	
	uint8_t _MotorRight_pin_F ;
        uint8_t _MotorRight_pin_B ;
	uint8_t _MotorRight_Enable ;
	uint8_t _MotorLeft_pin_F ;
	uint8_t _MotorLeft_pin_B ;
	uint8_t _MotorLeft_Enable ;
 
//===============================================================================================================================================================================
//===    ===========================================================  Functions for robot navigation              ============ ------------------- 
//===============================================================================================================================================================================

        //-----------------------------------------------------------------------------------------------------------------------------------corrects for heading error in moving robo
        void courseCorrection( float currentHeading, float targetHeading);
        
        //----------------------------------------------------------------------------------------------------------corrects motor speed. Used by "courseCorrection" function internally
        void speedController(boolean rightDeviation, boolean leftDeviation, float headingDiff);
        
	bool moveStraight(uint16_t tempCount, uint16_t distanceCount ,float heading, float targetHeading);
	bool turn(boolean directionFlag, float heading, float targetHeading);
 
//=========================================================================================================
//===================  Motor functions   يقرا من المكتبة  اللي اسمها 12cdev================================
//=========================================================================================================

	void moveForward(uint8_t speedRight = 255, uint8_t speedLeft = 255);//default full speed
	void moveBackward(uint8_t speedRight = 255, uint8_t speedLeft = 255);//default full speed
	void stop();//Stop both motor by disabling both
	void turnLeft(uint8_t speedRight = 255);//left wheel stop right moving to turn
	void turnRight(uint8_t speedLeft = 255);//right wheel stop left moving to turn
	void turnLeftInPlace(uint8_t speedRight = 255, uint8_t speedLeft = 255);//both moving in opposite direction for turn
	void turnRightInPlace(uint8_t speedRight = 255, uint8_t speedLeft = 255);//both moving in opposite direction for turn

};
