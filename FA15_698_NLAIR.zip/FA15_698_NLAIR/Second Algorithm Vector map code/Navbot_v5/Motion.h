

#ifndef MOTION_H_
#define MOTION_H_

#include "Vector.h"
#include "common.h"

class Motion {
public:
	Vector reqSpeed;  // the speed vector towards destination
	Vector errSpeed;  // the error for the feedback loop 
	void setSpeeds(Vector *, Vector *);
};

#endif /* MOTION_H_ */

