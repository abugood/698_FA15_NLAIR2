#include "WorldMap.h"

/**
 * Create an empty world surrounded by external wall
 */
WorldMap::WorldMap() {
	vectorMap = VectorMap();
	mapGraph = MapGraph(&vectorMap);
}

void WorldMap::setup() {

	// Initial cleanup
	vectorMap.clearMap();

	// Add Vertices

	// Exit: index 0    Target point                   ----------------------------------------------------نقطة النهاية
	vectorMap.addMapVertex(Coords(100, 100));

	// Robot: index 1         starting point              -------------------------------------------------- نقطة البداية 
	vectorMap.addMapVertex(Coords(100, 50));

	// Walls Vertices ------------------------------------------------------------ كانت 2*4 والان 2*2 غير هنا حسب حجم الخريطه الان 1 في 1 والان 2في3
	vectorMap.addMapVertex(Coords(0, 0));		// #2
	vectorMap.addMapVertex(Coords(0, 200));	// #3
	vectorMap.addMapVertex(Coords(200, 200));	// #4
	vectorMap.addMapVertex(Coords(200, 0));	// #5

	// Add Edges

	// Walls Edges    ----------------------------------------------نقاط التلاقي بين الجدران لخريطه مربعه وومكن اضيف الخريطة للسيب
	vectorMap.addMapEdge(2, 3);
	vectorMap.addMapEdge(3, 4);
	vectorMap.addMapEdge(4, 5);
	vectorMap.addMapEdge(5, 2);

	// Generate the map graph for this vector map
	mapGraph.generateGraphFromMap();
}

