/*
 * Sensors.h
   // --------------------------------------- here : هذهالصفحة تشغل انواع السناسر المختلفة انكودرر  + سونار+  البوصلة
 */

#ifndef SENSORS_H_
#define SENSORS_H_

#include "common.h"
#include "SensedWorld.h"
#include "WorldMap.h"
#include "Sonars.h"  //ultrasonic
#include "Compass.h"

class Sensors {
public:
	void setup(SensedWorld *);      // initialize for all types of sensors encoders, sonar,and compass
	void readAll(SensedWorld *); // the sensors are read using Sensors.readAll(). Each time the sensors are read, their data are stored in SensedWorld

	Sonars sonars;
	Compass compass;
};

#endif /* SENSORS_H_ */

