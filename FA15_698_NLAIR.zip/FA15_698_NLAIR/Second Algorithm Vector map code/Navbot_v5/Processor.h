// Processor.h


#ifndef PROCESSOR_H_
#define PROCESSOR_H_

#include "SensedWorld.h"
#include "WorldMap.h"
#include "Motion.h"
#include "common.h"

#define MAX_ROUTE_WPS MAX_VERTEX_NUMBER //-----------------------------------------------------

class Processor {
private:
  float normalizeAngle(float);
// most imp ---------------------------------------------------------------------------------------- تعريفات مهمه جدا كدوال ومتغيرات عادية 
public:
  void setup(WorldMap *, SensedWorld *);
  void process(SensedWorld *, WorldMap *, Motion *);
  bool calibrationTest(SensedWorld *, WorldMap *, Motion *);
  void estimateDisplacements(SensedWorld *);
  bool doRun(SensedWorld *, WorldMap *, Motion *);
  void prepareToRun(SensedWorld *);
  float prepareToTurn(SensedWorld *);
  bool checkProximityAlert(SensedWorld *);
  bool doDistanceChecks(WorldMap *, SensedWorld *);
  void addObstacle(WorldMap *, SensedWorld *);
};

#endif /* PROCESSOR_H_ */

