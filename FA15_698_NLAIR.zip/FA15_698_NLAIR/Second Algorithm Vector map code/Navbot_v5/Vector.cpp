#include "math.h"
#include "Vector.h"

/**
 * Creates new vector given modulus, angle in trigonometric degrees (not compass degrees)--------------------------------زاوية مثلثية ليست درجة البوصلة   ننشيى معامل متجه جديد
 */
Vector::Vector(float rho, float theta) : rho(abs(rho)), theta(theta) {
}

/**
 * Creates new Vector given coordinates --------------------------------------------------------لازم تفهم ال رو    اش المعامل 
 */
Vector::Vector(Coords *coords) {
	rho = coords->modulus();
	theta = coords->angle();
}

/**
 * Get the Coords(X,Y) coordinates of this position vector ----------------------------------------------- ايجاد احداثيات  لمكان المتجة الحالي
 */
void Vector::toCoords(Coords *coords) {
	float rad = theta * M_PI / 180.; // --------------------------------------------------------------------------------------------
	coords->setXY(cos(rad) * rho, sin(rad) * rho);  // -----------------------------------------------------------------------------
}

/**
 * Rotate theta degree
 */
void Vector::rotateDeg(float theta) {
	this->theta += theta;
	this->theta = Coords::normalizeAngle(this->theta);
}

float Vector::getX() {
	float rad = theta * M_PI / 180.;
	return cos(rad) * rho;
}

float Vector::getY() {
	float rad = theta * M_PI / 180.;
	return sin(rad) * rho;
}

