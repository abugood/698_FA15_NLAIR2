#ifndef WORLDMAP_H_
#define WORLDMAP_H_

#include "Coords.h"
#include "VectorMap.h"
#include "MapGraph.h"
#include "common.h"

/**
 * The WorldMap models the external world using a vectorial representation
 * The origin of coordinates for our reference framework is in the SOUTH WEST corner
 * of the world, (LOWER LEFT)
 * X Coordinates grow from West to East
 * Y Coordinates grow from South to North
 *
 */

class WorldMap {
public:
	VectorMap vectorMap;
	MapGraph mapGraph;

	WorldMap();
	void setup();

};

#endif

