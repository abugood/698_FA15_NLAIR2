

#include "Motion.h"

/**
 * reqSpeed: the speed vector towards destination
 * errSpeed: the error for the feedback loop
 */
void Motion::setSpeeds(Vector *reqSpeed, Vector *errSpeed) {
	this->reqSpeed = *reqSpeed;       // ---------------------------------------------------------- here:  سيتم استدعائها من صفحة موتور.cpp
	this->errSpeed = *errSpeed;
}

