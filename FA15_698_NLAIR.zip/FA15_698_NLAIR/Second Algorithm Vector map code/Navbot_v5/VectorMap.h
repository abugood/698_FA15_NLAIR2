#ifndef VECTORMAP_H_
#define VECTORMAP_H_

#define MAX_VERTEX_NUMBER 18        //here -------------------------------------------- قد تكون 20 حسب الخريطة حقتي
#define MAX_EDGE_NUMBER 18

#include "Coords.h"

class VectorMap {
private:
	unsigned char nVertices = 0;
	unsigned char nEdges = 0;

	unsigned int mapVertices[MAX_VERTEX_NUMBER][2];    // -------------------------------------------------here   مو واضح ليش ال 2
	unsigned char mapEdges[MAX_EDGE_NUMBER][2];

public:
	void clearMap();
	unsigned char getNVertices();
	unsigned char addMapVertex(Coords coords);
	void setMapVertex(unsigned char index, Coords coords);       //-----------here  ترجع الزاوية
	Coords getMapVertex(unsigned char index);

	unsigned char getNEdges();
	unsigned char addMapEdge(unsigned char v1Index, unsigned int v2Index);
	void setMapEdge(unsigned char index, unsigned char v1Index, unsigned int v2Index);  //-----------here  ترجع الجدار بين الزاويتين
	unsigned char *getMapEdge(unsigned char index);
};
#endif
