/*
 * Compass.cpp
 *
 */

#include "Compass.h"

void Compass::setup(SensedWorld *sensedWorld) {
	doLog("Compass setup.\n");
	Wire.begin();
 //---------------------------------------------------------------------------------------------------------------------
//0011110b, I2C 7bit address of HMC5883  ---------------------------------------------تعريف للبوصلة ومكتبتها  7 بت
	Wire.beginTransmission(COMPASS_ADDR); //open communication with HMC5883
//----------------------------------------------------------------------------------------------------------------------
	Wire.write(0x00); // select configuration register A
	Wire.write(0x78); // 8-average, 75Hz sample rate

	// Set the gain to 1090 LSb/Gauss
	Wire.write(0x40); // 1.22 Gain

	// Put the HMC5883 IC into the correct operating mode
	// Wire.write(0b10000001); //one-time measurement mode, HS I2C
	// Wire.write(0x01); //one-time measurement mode, DISABLE HighSpeed I2C
	Wire.write(0x00); //continuous measurement mode, DISABLE HS I2C------------------------------------------------------------ راجع اعدادات البوصلة ومعدل الانحراف من سطر 13-24 بصفحة.اتش

	Wire.endTransmission();
// ----------------------------------------------------------------bring all coordinates x,y , time   from class senseworld
	setOffset(sensedWorld);
	doLog("Compass setup end.\n");
}

/**
 * Obtain current bearing ---------------------------------------------- نفس الشي  بيجيب كل الاحداثيات من كلاس سنسوورلد
 * 
 */
float Compass::readBearing() {
	int x,y,z; //triple axis data --------------------------------الاحداثيات ال 3

	//Read data from each axis, 2 registers per axis
	Wire.requestFrom(COMPASS_ADDR, 6);
	if(6<=Wire.available()){
		x = Wire.read()<<8; //X msb
		x |= Wire.read(); //X lsb
		z = Wire.read()<<8; //Z msb
		z |= Wire.read(); //Z lsb
		y = Wire.read()<<8; //Y msb
		y |= Wire.read(); //Y lsb
	}

	//Tell the HMC5883L where to begin start a new conversion------------------------------------- كيف تعلم البوصلة تبدا تحول جديد
	Wire.beginTransmission(COMPASS_ADDR);
	Wire.write(0x02); // Start a conversion
	Wire.write(0x00); //continuous measurement mode, DISABLE HS I2C
	Wire.endTransmission();

	// Use calibration parameters, as obtained manually for your current robot setup
	float xC = x*COMPASS_GAIN_FACT*X_GAIN_OFFSET + COMPASS_X_OFFSET;
	float yC = y*COMPASS_GAIN_FACT*Y_GAIN_OFFSET + COMPASS_Y_OFFSET;
	float zC = z*COMPASS_GAIN_FACT*Z_GAIN_OFFSET + COMPASS_Z_OFFSET;

	// tilt compensation
	float pitch = COMPASS_PITCH;
	xC = xC * cos(pitch) + zC * sin(pitch);

	float heading = atan2(yC, xC);
//   -----------------
	// Add your 'Declination Angle', find yours here: http://www.magnetic-declination.com/
	// In Pravia: 2 degree, or 0.035------------------------------------------------   السطر اعلاه اضاف زاوية الانحراف لموقعك الحقيقي تكون بين  .035 و  2 درجةالانحراف المغناطيسي
	float declinationAngle = -9.35;   //        -----------------------------------------here change the angle based on the place = -9,35  it was  = 0.035
	heading += declinationAngle;

	// Correct for when signs are reversed.
	if(heading < 0) heading += 2.*M_PI;

	// Check for wrap due to addition of declination.         --------------------------------------التحقق من وجود تشوه ضخم بالانحراف 
	if(heading > 2*M_PI) heading -= 2.*M_PI;

	// Convert radians to degrees for readability.                        -------------------------زاوية نصف قطريه حوله  درجة للانحراف 
	float headingDegrees = heading * 180./M_PI;

	// Substract offset  --------------------------------------------------------------------اطرح قيمه الخلل  خارج المسار 
	headingDegrees -= offset;
	// Check for wrap due to substraction of offset.  ---------------------------------------التاكد من تشوه بعد عملية طرح الخلل خارج المسار 
	if(headingDegrees < 0) headingDegrees += 360;

	return headingDegrees;
}

/**
 * Obtain current bearing and save it in SensedWorld
 * 
 * The output is stored in sensedWorld->bearingDeg
 * Data in "compass degress" (North is 0º, EAST 90º...)
 * 
 */
void Compass::readBearing(SensedWorld *sensedWorld) {
	sensedWorld->bearingDeg = readBearing();
}

void Compass::setOffset(SensedWorld *sensedWorld) {
	offset = 0; // As offset is used inside readBearing, we need to reset it now
	readBearing(sensedWorld);readBearing(sensedWorld);readBearing(sensedWorld); // Discard some readings
	readBearing(sensedWorld);
	offset = sensedWorld->bearingDeg;
}

