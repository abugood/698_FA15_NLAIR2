/*
 * Vector.h
 */

#ifndef VECTOR_H_
#define VECTOR_H_

#include "Coords.h""

class Vector {
public:
	float rho;		// Modulus
	float theta;	// Angle in trigonometric degrees----------------------------------------------------- زاوية مهمه توضح مدى كبر او صغر الزاوية عن اتجاه الهدف

	Vector(float rho = 0, float theta = 0);
	Vector(Coords *);
	void toCoords(Coords *);
	void rotateDeg(float theta);
	float getX();
	float getY();

	/**
	 * Translates from compass degrees to standard degreees  ---------------------------------------------تحول من زاوية البوصلة الى الزاوية الحقيقية
	 * and the opposite
	 */
	static inline double to_other_degrees(double deg_in) {
		return fmod(360. + 90. - deg_in, 360.);
	}
};

#endif /* VECTOR_H_ */

