

#ifndef MOTOR_H_
#define MOTOR_H_

#include "Motion.h"
#include "SensedWorld.h"
#include "common.h"

extern Motion motion;

class Motor {
private:
  boolean turnDirection(float currentBearing, float targetBearing);
  void turnLeft(float currentBearing, float targetBearing);
  void turnRight(float currentBearing, float targetBearing);
  void setLeftPower(int);
  void setRightPower(int);
  void waitStop();
  void resetCounters();
  
public:
  void setup();
  boolean writeAll(Motion *);
  boolean turn(float currentBearing, float targetBearing);
  void stop();
  void fullStop();  
};

#endif /* MOTOR_H_ */

