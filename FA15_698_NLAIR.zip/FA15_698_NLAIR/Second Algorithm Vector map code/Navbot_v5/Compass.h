/*
 * Compass.h
  */

#ifndef COMPASS_H_
#define COMPASS_H_

#include "common.h"
#include "SensedWorld.h"
#include "Vector.h"
#include <Wire.h>

#define COMPASS_ADDR 0x1E //0011110b, I2C 7bit address of HMC5883  ---------------------------------------------تعريف للبوصلة ومكتبتها  7 بت

// Data from Test 5, ROBOT #2 ------------------------------------------------------------------------------معايرة احداثيات البوصلة بداية س وال ص وال ز
#define X_GAIN_OFFSET     1.04
#define Y_GAIN_OFFSET     1.07
#define Z_GAIN_OFFSET     1.01
#define COMPASS_X_OFFSET  245.88
#define COMPASS_Y_OFFSET  78.68
#define COMPASS_Z_OFFSET  388.52
#define COMPASS_GAIN_FACT  1.22    //--------------------------------------
// Compass tilt of +20deg = +0.349 rad  --------------------------------------- طريقة حساب البوصلة مع الميلان  20درجة بكل اتجاه والسطر التالي يعرض االهتزاز او المعدل وتعويض الانحراف
#define COMPASS_PITCH +0.349

class Compass {
private:
	float offset;          //    ----------------------------rate of diverte
	float readBearing();   // ------------------------------- 
public:
	void setup(SensedWorld *);
	void setOffset(SensedWorld *);
	void readBearing(SensedWorld *);
};

#endif /* COMPASS_H_ */

