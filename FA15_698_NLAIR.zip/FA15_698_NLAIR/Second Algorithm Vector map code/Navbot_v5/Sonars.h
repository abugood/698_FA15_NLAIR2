// Sonars.h

#ifndef SONARS_H_
#define SONARS_H_

#include "common.h"
#include "SensedWorld.h"
#include <NewPing.h>

#define SONAR_NUM 3

class Sonars {
public:
	void setup();
	void readAll(SensedWorld *);
	// Last read distance to obstacles------------------------------------------------  يعطي اخر قراءة عن العائق ونوعه بايت بمتغير الاتجاه
	unsigned int getFreeSpace(Byte direction);
};

#endif

