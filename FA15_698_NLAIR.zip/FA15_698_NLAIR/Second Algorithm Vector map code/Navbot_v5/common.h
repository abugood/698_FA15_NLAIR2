/*
 * common.h
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <Arduino.h>

#define ARDUINO_DEBUG

// Motor control related parameters
// Wheel data: cm traversed per slot counted
#define CM_PER_SLOT 1.035
// Motor base speed
#define RUN_BASE_SPEED 60         	// With this value we see maximum speeds of around 31cm/sec = was 80
#define SPEED_CHECK_INTERVAL 100  	// Time in mSecs between instant speed check = was 100
#define DISTANCE_CHECK_INTERVAL 50	// Time in mSecs between distance check = was 150

// Motor run PID Adjust
#define KP (RUN_BASE_SPEED/10)
#define KI 0
#define KD 0.5   //------------------------------------------------------------------------------------fixed
#define PID_SAMPLE_TIME 10
#define PID_MIN_OUTPUT (-2 * RUN_BASE_SPEED)
#define PID_MAX_OUTPUT (+2 * RUN_BASE_SPEED)

// Turn control parameters
#define TURN_CHECK_INTERVAL 1
#define MIN_MOTOR_POWER  255 * 0.15
#define MOTOR_POWER_INC  255.0 * 0.35 / 100   // 0.75% per CHECK_INTERVAL
#define DEGREE_PRECISSION 2 // In degree

// Exit is always the reference node
#define EXIT_NODE 0
#define ROBOT_NODE 1

// Tunable parameters
#define WORLD_TILE_CM 30
#define MAX_DISTANCE 400 // Maximum distance (in cm) to ping.
#define SONAR_PING_INTERVAL 50 // Milliseconds between sensor pings
							   // (50ms is about the min to avoid cross-sensor echo @ 4meters, 33ms for 2 meters).

// Motor pins
#define LMSPD	10	// Left Motor Speed, ENA. Pin 10
#define LMS_1	11	// Left Motor Select 1, IN1. Pin 9
#define LMS_2	8	// Left Motor Select 2, IN1. Pin 8
#define RMSPD	9	// Right Motor Speed, ENB. Pin 11
#define RMS_3	13	// Right Motor Select 3, IN3. Pin 13
#define RMS_4	12	// Right Motor Select 4, IN4. Pin 12

// Sonar pins
#define USFP	7	// UltraSound Front Ping
#define USFE	6	// UltraSound Front Echo
#define USLP	A0	// UltraSound Left Ping
#define USLE	A1	// UltraSound Left Echo
#define USRP	A2	// UltraSound Right Ping
#define USRE	A3	// UltraSound Right Echo

// Wheel encoders pins
#define LEFT_WEP 	2
#define RIGHT_WEP	3

// State machine states
#define PREPARE_TO_RUN_STATE 0
#define RUNNING_STATE 1
#define PREPARE_TO_TURN_STATE 2
#define TURNING_STATE 3
#define CHECKING_STATE 4
#define PREPARE_TO_FIX_STATE 5

#ifdef ARDUINO_DEBUG
template<typename TYPE>void doLog(TYPE value) { Serial.print(value); }
#else
#  define doLog(...)
#endif

#define Byte unsigned char

#endif /* COMMON_H_ */

