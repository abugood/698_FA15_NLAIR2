

#include "Motor.h"

/**
 * The motor is driven by a L298N driver
 * Pinout:
 *
 * Pin  Type	Function
 *
 * 10   PWM  	LM Speed (EN A)
 * 9	D 		LM Select_1 (IN 1)
 * 8	D		LM Select_2 (IN 2)
 * 11	PWM		RM Speed (EN B)
 * 12	D		RM Select_1 (IN 3)
 * 13	D		RM Select_2 (IN 4)
 *
 */

// PID variables------------------------------------  proportional integral Derivative  اشتقاق تناسبي تكاملي  شغل هندسة كهربائية بحت
double kp, ki, kd;
unsigned long lastTime;
double ITerm, lastInput;

int lastLeftCount, lastRightCount;  // ------------------------------- here:  عداد  يحسب للجهة  اخر قراءة
unsigned long turnNextCheck;

// Globals defined externally -----------------------------------------متغيرات قلوبل عامةواكستيرن  تستخدم اذا عندك متغيرات قلوبل 
extern unsigned long leftCounter;
extern unsigned long rightCounter;
extern float leftMotorPower;
extern float rightMotorPower;

/**
 * PID Control
 */
double computePID(double Setpoint, double Input) {
	unsigned long now = millis();
	int timeChange = (now - lastTime);
	if (timeChange>=PID_SAMPLE_TIME) {
		/*Compute all the working error variables*/
		double error = Setpoint - Input;
		ITerm+= (ki * error);
		if(ITerm > PID_MAX_OUTPUT) ITerm= PID_MAX_OUTPUT;
		else if(ITerm < PID_MIN_OUTPUT) ITerm= PID_MIN_OUTPUT;
		double dInput = (Input - lastInput);

		/*Compute PID Output*/
		double Output = kp * error + ITerm- kd * dInput;
		if(Output > PID_MAX_OUTPUT) Output = PID_MAX_OUTPUT;
		else if(Output < PID_MIN_OUTPUT) Output = PID_MIN_OUTPUT;

		/*Remember some variables for next time*/ // -------------------------------------------------------here : تذكرها
		lastInput = Input;
		lastTime = now;

		return Output;
	} else {
		return -256;
	}
}

void Motor::setup() {
	pinMode(LMSPD,   OUTPUT);
	pinMode(LMS_1,   OUTPUT);
	pinMode(LMS_2, OUTPUT);
	pinMode(RMSPD, OUTPUT);
	pinMode(RMS_3, OUTPUT);
	pinMode(RMS_4, OUTPUT);

	double SampleTimeInSec = ((double)PID_SAMPLE_TIME)/1000; // -------here :     عينة الوقت بالثانية 
	kp = KP;
	ki = KI * SampleTimeInSec;
	kd = KD / SampleTimeInSec;

	kp = (0 - kp);
	ki = (0 - ki);   
	kd = (0 - kd);
}

/**
 * motion contains reqSpeed, a vector with desired speed and
 * and errSpeed, a vector with the error for the feedback loop 
 * ---------------------------------------------------------------------------reqSpeed: the speed vector towards destination
 * ---------------------------------------------------------------------------errSpeed: the error for the feedback loop 
 * 
 */
bool Motor::writeAll(Motion *motion) {      // ---------------------------------------here  دالة معرفة قلوبل معرفة فوق عشان كذا استخدمنا اكستيرن معها

	// We must provide commands to our motor given provided motion
	// Using differential impulse to keep track during "hops"  -----------------محاولة الحفاظ عالمسار بدفعات مختلفة للموتور
	// Use PID to find out the Output required to compensate drift -------------للوقوف عالنتايج المطلوبة لتعويض الانحراف
	// The error is given in motion.errSpeed.theta
	// The output is the required differential impulse

	double setPoint = motion->reqSpeed.theta;
	double input = setPoint - motion->errSpeed.theta;
	double u = computePID(setPoint, input);

	if (u!=-256) {
		float baseSpeed = motion->errSpeed.rho;// -----------------------------------------------------------here: راجع صفحة vector.h.cpp
		float lSpeed = baseSpeed + u/2;
		float rSpeed = baseSpeed - u/2;

		setLeftPower(lSpeed);
		setRightPower(rSpeed);
	}

	return true;
}

/**
 * Stop both motors immediately and waits until both wheels have stopped for at least 25 mSecs
 */
void Motor::fullStop() {
	stop();
	waitStop();
	resetCounters();
}

/**
 * Stop both motors immediately
 */
void Motor::stop() {
	leftMotorPower = 0;//--------------------------both float
	rightMotorPower = 0;
	setLeftPower(leftMotorPower);//----------------------------------here: دالة ترجع رقم من نوع انتولكن هنا  ترجع المتغير اللي فوقها  leftmotorpower
	setRightPower(rightMotorPower);// -------------------------------here: دالة ترجع رقم من نوع انتولكن هنا  ترجع المتغير اللي فوقها  leftmotorpower
}

/**
 * Waits until both wheels have stopped for at least 25 mSecs
 */
void Motor::waitStop() {
	unsigned long now;
	int lastIterationLeftCounter = leftCounter;   // ---------------------------------------review line 29-30
	int lastIterationRightCounter = rightCounter; // ---------------------------------------review line 29-30
	turnNextCheck = millis() + 25;
	while (true) {
		now = millis();
		if (now > turnNextCheck) {
			if (leftCounter > lastIterationLeftCounter) {
				lastIterationLeftCounter = leftCounter;
			} else if (rightCounter > lastIterationRightCounter) {
				lastIterationRightCounter = rightCounter;
			} else {
				break;
			}
			turnNextCheck = now + 25;
		}
	}
}

void Motor::resetCounters() {
	leftCounter = 0;
	rightCounter = 0;
	lastLeftCount = 0;
	lastRightCount = 0;
}

/**
 * currentBearing: current bearing as read by compass, in compass degrees. Always positive
 * targetBearing: requested bearing as calculated by prepareToTurn(), in compass degrees. Always positive
 * 
 */
boolean Motor::turn(float currentBearing, float targetBearing) {

	unsigned long now = millis();
	if (now < turnNextCheck) {
		return false;
	}
	turnNextCheck = now + TURN_CHECK_INTERVAL;  //---------------------------------------------- here :  عبارة عن رقم من نوع لونق

	/*
Serial.print("CB:");
Serial.print(currentBearing);//----------------------------------------------------------------------------- يقوم بطباعتها على سيريال مونيتور
Serial.print(" - TB:");
Serial.println(targetBearing);
	 */

	// Check if finished turning-------------------------------------------------------------------------عملية التاكد هل انهى الالتفاف ام لا
	if (abs(targetBearing - currentBearing) <= DEGREE_PRECISSION) {         //--------------------------here يقصد ابسوليوت فاليو
		stop(); // This is to assure that the motors are braked
		return true;
	}

	if (turnDirection(currentBearing, targetBearing)) {     //-----------------now   يشيك الاتجاه للالتفاف
		turnRight(currentBearing, targetBearing);
	} else {
		turnLeft(currentBearing, targetBearing);
	}
	setLeftPower(leftMotorPower);
	setRightPower(rightMotorPower);

	return false;
}

/**
 * Given two bearings, current and target, find what is the 
 * direction to move from current to target
 * 
 * return true for turn right, false for turn left
 */
boolean Motor::turnDirection(float currentBearing, float targetBearing) {   // -----------------------------------here:  بعد مالف الان  الاتجاه من المكان الحالي للهدف
	if (targetBearing>180) {
		if (currentBearing>targetBearing || (currentBearing<targetBearing-180) ) {
			return false;
		} else {
			return true;
		}
	} else {
		if (currentBearing<targetBearing || (currentBearing>targetBearing+180) ) {
			return true;
		} else {
			return false;
		}
	}
}

/**
 * targetBearing the target bearing-----------------------------------------------------------------------------------الاتجاه للهدف
 */
void Motor::turnLeft(float currentBearing, float targetBearing) {

	// Check if there has been a tick increment
	if (leftCounter > lastLeftCount) {
		leftMotorPower = -MIN_MOTOR_POWER; // ----------------------------------------------reset Motor Power
		lastLeftCount = leftCounter;
	} else {
		// Continue incrementing power  ----------------------------------------------------او يزيد قوة المحرك يواصل
		leftMotorPower += -MOTOR_POWER_INC;
	}

	if (rightCounter > lastRightCount) {
		rightMotorPower = MIN_MOTOR_POWER; // ----------------------------------------------reset Motor Power
		lastRightCount = rightCounter;
	} else {
		// Continue incrementing power
		rightMotorPower += MOTOR_POWER_INC;
	}
}

/**
 * targetBearing: the target bearing
 */
void Motor::turnRight(float currentBearing, float targetBearing) {

	// Check if there has been a tick increment
	if (leftCounter > lastLeftCount) {
		leftMotorPower = MIN_MOTOR_POWER; // reset Motor Power
		lastLeftCount = leftCounter;
	} else {
		// Continue incrementing power
		leftMotorPower += MOTOR_POWER_INC;
	}

	if (rightCounter > lastRightCount) {
		rightMotorPower = -MIN_MOTOR_POWER; // reset Motor Power
		lastRightCount = rightCounter;
	} else {
		// Continue incrementing power
		rightMotorPower += -MOTOR_POWER_INC;
	}
}

/**
 * Left motor power set----------------------------------------------------------------تشغيل هاي و لو للمحرك الايسر
 */
void Motor::setLeftPower(int power) {
	// Select direction
	if (power>0) {
		digitalWrite(LMS_1, HIGH);
		digitalWrite(LMS_2, LOW);
	} else if (power<0) {
		power = -power;
		digitalWrite(LMS_1, LOW);
		digitalWrite(LMS_2, HIGH);
	} else {
		// brake the motor
		digitalWrite(LMS_1, LOW);
		digitalWrite(LMS_2, LOW);
	}
	Byte pwm = power;
	analogWrite(LMSPD, pwm);
}

/**
 * Right motor power set -------------------------------------------------------------تشغيل هاي و  لو  للمحرك الايمن
 */
void Motor::setRightPower(int power) {
	// Select direction
	if (power>0) {
		digitalWrite(RMS_3, HIGH);
		digitalWrite(RMS_4, LOW);
	} else if (power<0) {
		power = -power;
		digitalWrite(RMS_3, LOW);
		digitalWrite(RMS_4, HIGH);
	} else {
		// brake the motor
		digitalWrite(RMS_3, LOW);
		digitalWrite(RMS_4, LOW);
	}
	Byte pwm = power;
	analogWrite(RMSPD, pwm);
}
