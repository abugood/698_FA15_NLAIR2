// SensedWorld.h
// here ------------------------------------------------------------------------------هذه الصفحة تاخذ كل مدخلاتها من صفحة  سنسور.اتش و.سي بي بي  بواسطة انواع السناسر بوصلة انكودر وسونار
#ifndef SENSEDWORLD_H_
#define SENSEDWORLD_H_

#include "common.h"

class SensedWorld {
public:
	SensedWorld();
	Byte getXDisp();
	Byte getYDisp();
	float getXCmDisp();
	float getYCmDisp();
	float getBearingDeg();
	void updateTimeTag();
	unsigned long getCurrentTimeTag();
	void setFreeSpace(Byte, float);
	boolean checkProximityAlert();

	// The timeTag indicates when the current data was obtained, in microseconds
	unsigned long timeTag;
	// The timeSlices accumulates the number of times sensors were read
	unsigned long timeSlices;

	// The free space in front of each sonar
	float freeSpace[3];

	float xCmPos;	// X Position, in cm, in sensedWorld, as calculated given sensors information
	float yCmPos;	// Y Position, in cm, in sensedWorld, as calculated given sensors information
	float xCmDelta;	// X delta, in cm, in sensedWorld, of current hop
	float yCmDelta;	// Y delta, in cm, in sensedWorld, of current hop

	float bearingDeg;	// The brearing as read from compass (compass degrees)

	bool obstacleFound;

	float instantSpeed;
};

#endif /* SENSEDWORLD_H_ */

