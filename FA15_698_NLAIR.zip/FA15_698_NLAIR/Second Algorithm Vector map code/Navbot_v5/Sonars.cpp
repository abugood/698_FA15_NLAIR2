/*
 * Sonars.cpp
 */

#include "Sonars.h"

// These must be global variables, as they are accessed in timer interrupt
unsigned long pingTimer[SONAR_NUM]; // Holds the times when the next ping should happen for each sensor.
float cm[SONAR_NUM];         		// Where the ping distances are stored.
Byte currentSensor = 0;          	// Keeps track of which sensor is active.----------------------------------------------------------- هذا المتغير يشيك اي الحساسات شغال اكتف الان 

NewPing sonarPing[SONAR_NUM] = {   			// Sensor object array.
	  NewPing(USFP, USFE, MAX_DISTANCE), 	// FRONT sensor's trigger pin, echo pin, and max distance to ping.
	  NewPing(USLP, USLE, MAX_DISTANCE),	// LEFT sensor's trigger pin, echo pin, and max distance to ping.
	  NewPing(USRP, USRE, MAX_DISTANCE),	// RIGHT sensor's trigger pin, echo pin, and max distance to ping.
};

void Sonars::setup() {
	  pingTimer[0] = millis() + 75;           // First ping starts at 75ms, gives time for the Arduino to chill before starting.---------------------------------------------------***
	  for (Byte i = 1; i < SONAR_NUM; i++) // Set the starting time for each sensor.
	    pingTimer[i] = pingTimer[i - 1] + SONAR_PING_INTERVAL;
}

/**
 * Global function, as needs to be accessed from timer interrupt
 */
void echoCheck() { // If ping received, set the sensor distance to array.
	if (sonarPing[currentSensor].check_timer()) {
		cm[currentSensor] = sonarPing[currentSensor].ping_result / (float)US_ROUNDTRIP_CM;
	}
}

/**
 * Starts asynchronous reading of sonar. Data is acquired in "echoCheck"------------------------- ممتاز كل سنسور يعمل لوحده بوقت متتابع في لووب  لانه لو كلهم اشتغلوا بنفس الوقت مشكلة
 */
void Sonars::readAll(SensedWorld *sensedWorld) {
	for (Byte i = 0; i < SONAR_NUM; i++) { //--------------------------------------------------Loop through all the sensors.
		if (cm[i] > 0) {
			sensedWorld->setFreeSpace(i, cm[i]);	// ----------------------------------------------Save the latest read value in sensedWorld
		}
		if (millis() >= pingTimer[i]) {         // here : -------------------------------------- يحفظ لكل حساس الوقت للعملية بنق المفترضة القادمة
			pingTimer[i] += SONAR_PING_INTERVAL * SONAR_NUM;  // Set next time this sensor will be pinged.
			sonarPing[currentSensor].timer_stop();          // Make sure previous timer is canceled before starting a new ping (insurance).
			currentSensor = i;                          // Go for next Sensor.
			cm[currentSensor] = 0;                      // Make distance zero in case there's no ping echo for this sensor.
			sonarPing[currentSensor].ping_timer(echoCheck); // Do the ping (processing continues, interrupt will call echoCheck to look for echo).
		}
	}
}

