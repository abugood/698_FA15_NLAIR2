// Sensors.cpp

#include "Sensors.h"
#include "Vector.h"

unsigned int counter = 0;
unsigned long lastTimeTag = 0;
unsigned long lastTimeSlices = 0;

unsigned long nextWheelTestTimeTag = 0;
unsigned long lastWheelTestTimeTag = 0;
unsigned long leftCounter = 0;
unsigned long rightCounter = 0;
unsigned long nextLeftCount;
unsigned long nextRightCount;

/**
 * Prepare all sensors------------------------------------------------------------- يحسب كم مشى الانكودر
 */
void LeftEncoderEvent() {
  if (millis() > nextLeftCount) {
  	leftCounter++;
    nextLeftCount = millis() + 15;
  }
}
void RightEncoderEvent() {
  if (millis() > nextRightCount) {
    rightCounter++;
    nextRightCount = millis() + 15;
  }
}

void Sensors::setup(SensedWorld *sensedWorld) {
	sonars.setup();
	compass.setup(sensedWorld);

	// Prepare the encoders
	attachInterrupt(0, LeftEncoderEvent, RISING);
	attachInterrupt(1, RightEncoderEvent, RISING);
}

bool reported = false;

/**
 * This routine is executed frequently, to try to match the real world with the sensed world
 * After all sensors are read, the data from all of them is fused into sensedWorld ----------------------------------------  الدالة ريدال  تحفظ قراءة القديمة وتحفظها ب لاست والجديدة في نكست
 */
void Sensors::readAll(SensedWorld *sensedWorld) {
	unsigned long now = millis();
	if (now > nextWheelTestTimeTag) {
		nextWheelTestTimeTag = now + 1e3;
	}
	lastWheelTestTimeTag = millis();

	// ---------------------------------------------------------------------------------------------------Update the distances to obstacles from all 3 or 4 UltraSound devices
	// ---------------------------------------------------------------------------------------------------Every 132 mSecs we have new readings for all three or four sonars
	// ---------------------------------------------------------------------------------------------------Readings are non blocking, so the robot can do other things while
	// ---------------------------------------------------------------------------------------------------waiting for the ultasonic sound waves to return
	sonars.readAll(sensedWorld);

	// Read data from compass into bearingDeg
	compass.readBearing(sensedWorld);

	sensedWorld->updateTimeTag();
}


