#include "Coords.h"

Coords::Coords(int x, int y) : x(x), y(y) {
}

void Coords::setXY(int x, int y) {
	this->x = x;
	this->y = y;
}

int Coords::getX() {
	return x;
}

int Coords::getY() {
	return y;
}
//                    --------------------------------------------------divided x /tile
int Coords::getTileX() {
	return round(x / WORLD_TILE_CM);
}

int Coords::getTileY() {
	return round(y / WORLD_TILE_CM);
}
//-----------------------------------------------------------------------------------------------------------
float Coords::modulus() {
	return sqrt((long)x*x + (long)y*y);
}
//-----------------------------------------------------------------------------------------------------------
/**
 * Returns the angle of the position vector, in trig degree, [0,360)      ------------------------------------ مثل درجة الثيتا  لكن هنا البوصله 
 */
float Coords::angle() {
	float rads = (x==y && x==0)?0:atan2(y, x);
  float angle = rads * 180 / M_PI;
  float retValue = normalizeAngle(angle);

	return retValue; //          ---------------------------------------------------------------------------------------return angle
}

boolean Coords::equals(Coords *coords) {
	return (x==coords->x && y==coords->y);
}

void Coords::add(Coords *coords2) {
	x += coords2->x;
	y += coords2->y;
}

void Coords::substract(Coords *coords2) {
	x -= coords2->x;
	y -= coords2->y;
}

/**
 * Returns angle positive, [0,360) -------------------------------------------------------------تطبيق الزاوية ع الاتجاه الصحيح
 */
float Coords::normalizeAngle(float angle) {
  float normalizedAngle = fmod(angle, 360.);
  if (normalizedAngle<0) {
    normalizedAngle += 360;
  }
  return normalizedAngle;
}

