#include "MapGraph.h"

MapGraph::MapGraph() {
}
//-------------------------------------------------------------------------------------------This is the third part of the algorithim ***************************************

MapGraph::MapGraph(VectorMap *vectorMap) {
	this->vectorMap = vectorMap;
}
// ---------------------------------------------------------------------------------------------------------------------------------------------setEdge---------------------------***
void MapGraph::setEdge(unsigned char v1, unsigned char v2, unsigned int distance) {
  if( v2>v1) {
    int s = v1; v1=v2; v2=s;
  }
  graphEdges[v1*(v1+1)/2 + v2] = distance;
}

unsigned int MapGraph::getEdge(unsigned char v1, unsigned char v2) {
  if( v2>v1) {
    int s = v1; v1=v2; v2=s;
  }
  return graphEdges[v1*(v1+1)/2 + v2];
}
// ------------------------------------------------------------------------------------------------------------------------------------------   getPath   ------------------------***
unsigned char *MapGraph::getPath() {
	return prev;
}

/**
 * Populate the Graph with Edges                          تعبة الرسم البياني مع حواف الحريطة
 */
void MapGraph::generateGraphFromMap() {  //==========================================================================================================================================*****
  
  // Not needed to add Vertices to Graph, because graphVertices are mapVertices------------------------------------------- عدد الحواف  يساوي عدد الزوايا   لانحتاج نزود اي شي 

  // clean all graph edges
  for(int i=0; i<MAX_VERTEX_NUMBER;i++)
    for(int j=0; j<MAX_VERTEX_NUMBER;j++)
      setEdge(i, j, 0);

  for(int i=0; i<vectorMap->getNVertices(); i++) {
    for(int j=i+1; j<vectorMap->getNVertices(); j++) {
      
      // Get segment given by Vertex i and Vertex j ----------------------------------------------------  شوف الجزء المعطى بين الزاويتين
      // Then check against all possible obstacles: the Map edges---------------------------------------قم بالتشييك على  كل العوائق المحتملة  الحواف 

      if (!checkConnectionIntersections(i, j, vectorMap->getNEdges())) {
        continue; // Do not add this connection: intersects object.--------------------------------------------------------  موواضح كثير
      }

      // If not intersects, add this segment as connection to Graph ------------------------------------- اذا لم تتلاقى الاحداثيات اضف هذا الجزء
      Coords v1 = vectorMap->getMapVertex(i);
      Coords v2 = vectorMap->getMapVertex(j);
      int dist = sqrt( pow((float)v1.getX()-v2.getX(), 2) + pow((float)v1.getY()-v2.getY(), 2));                   // complex number
      setEdge(i, j, dist); //    ------------------------------------------------------------------------------------------------------------------------here get function 3 values--****
    }
  }
}
//================================================================================================================================================================================

// ------------------------Funtion that implements Dijkstra's single source shortest path algorithm--------------------------------------نفس طريقة الويف فرونت للخط الاقصر
// ----------------------- We only focus on finding shortest path to dest

unsigned int MapGraph::solve(int src, int dest) { 
  Serial.println("Solving Map \n\n");


  
     // Initialize all distances as INFINITE, stpSet[] as false, and path nodes cleaned -------------------------- سيتم استدعائها من صفحة بروسسور .cpp================================-***
     
     for (int i = 0; i < vectorMap->getNVertices(); i++)
        dist[i] = INT_MAX, sptSet[i] = false, prev[i] = 0;
 
     // Distance of source vertex from itself is always 0      -------------------------------------------------دايما المسافة من مصدر الزاوية نعبره صفر
     dist[src] = 0;
 
     // Find shortest path for all vertices
     for (int count = 0; count < vectorMap->getNVertices()-1; count++) {
      
       // Pick the minimum distance vertex from the set of vertices not------------------------------------------------خذ الزاوية الاقل مسافة 
       // yet processed. u is always equal to src in first iteration.
       
       int u = minDistance(dist, sptSet, vectorMap->getNVertices()); //-------------------------------------------------------------------------------- MinDistance ------------------***

       // The requested node has been found
       if (u == dest) {
        return dist[u];
       } 
       
       // Mark the picked vertex as processed
       sptSet[u] = true;
 
       // Update dist value of the adjacent vertices of the picked vertex.
       for (int v = 0; v < vectorMap->getNVertices(); v++) {
         // Update dist[v] only if is not in sptSet, there is an edge from 
         // u to v, and total weight of path from src to  v through u is 
         // smaller than current value of dist[v]
         if (!sptSet[v] && getEdge(u,v) && dist[u] != INT_MAX 
                                       && dist[u]+getEdge(u,v) < dist[v]) {
            dist[v] = dist[u] + getEdge(u,v);
            // Here one node has one and only one origin
            prev[v] = u;
          
         }
       }
     }
}

/**
 * Check this connection against all Map Edges.--------------------------------------------------------------اعطاء التقاطعات
 * If there is a collision, return false
 */
bool MapGraph::checkConnectionIntersections(int i, int j, int edges) {
  Coords a1 = vectorMap->getMapVertex(i);
  Coords a2 = vectorMap->getMapVertex(j);

  // Traverse all the Map Edges: obstacles------------------------------------------------------اجتياز او تخطي الحواف 
  for(int k=0; k<edges; k++) {
    Coords b1 = vectorMap->getMapVertex(vectorMap->getMapEdge(k)[0]);
    Coords b2 = vectorMap->getMapVertex(vectorMap->getMapEdge(k)[1]);

    // If the segment has a vertex in common with this Edge, consider it NOT INTERSECTING
    if (a1.equals(&b1) || a1.equals(&b2) || a2.equals(&b1) || a2.equals(&b2)) continue;
    
    if (intersects(&a1, &a2, &b1, &b2)) {
      return false;
    }
  }

  return true;
}

/**
 * Get closest intersection of this segment against all Map Edges.
 *
 * a1: Coords of origin vertex
 * a2: Coords of other vertex, MAX_DISTANCE cm away
 *
 * returns: distance from a1 to closest intersection, -1 means no intersection---------------------------------   -1 لم يتقاطعوا     ثم اختر التقاطع الاقرب
 */
int MapGraph::getClosestIntersection(Coords *a1, Coords *a2) {
  int retVal = -1;
  Coords intersection = Coords(0,0);

  // Traverse all the Map Edges: obstacles
  for(int k=0; k<vectorMap->getNEdges(); k++) {
    Coords b1 = vectorMap->getMapVertex(vectorMap->getMapEdge(k)[0]);
    Coords b2 = vectorMap->getMapVertex(vectorMap->getMapEdge(k)[1]);

    // If the segment has a vertex in common with this Edge, consider it NOT INTERSECTING
    if (a1->equals(&b1) || a1->equals(&b2) || a2->equals(&b1) || a2->equals(&b2)) continue;

    if (whereIntersects(a1, a2, &b1, &b2, &intersection)) {
      // set this as the distance if unset or if lower than set value
      intersection.substract(a1);
      int distance = intersection.modulus();
      if (retVal < 0 || distance < retVal) retVal = distance;
    }
  }

  return retVal;
}
// ---------------------------------------------------------------------------------------------------------------
// A utility function to find the vertex with minimum distance value, from   ---------------------  ايجاد الزاوية الاقل مسافة عشان يكمل من حولها
// the set of vertices not yet included in shortest path tree


int MapGraph::minDistance(unsigned int dist[], bool sptSet[], int vertices) {
   // Initialize min value
   int min = INT_MAX, min_index;
 
   for (int v = 0; v < vertices; v++) {
     if (sptSet[v] == false && dist[v] <= min)
         min = dist[v], min_index = v;
   }
 
   return min_index;
}
// -------------------------------------------------------------------------------------------------------------------------------------
// a1 is line1 start, a2 is line1 end, b1 is line2 start, b2 is line2 end  ------------------------------------------------------------- بداية النقطة من الاصل الى النقطة المطلوبة س والاخر ص
bool MapGraph::intersects(Coords *a1, Coords *a2, Coords *b1, Coords *b2) {
  Coords b = Coords(*a2); b.substract(a1);
  Coords d = Coords(*b2); d.substract(b1);
  float bDotDPerp = (long)b.getX() * d.getY() - (long)b.getY() * d.getX();

  // if b dot d == 0, it means the lines are parallel so have infinite intersection points     ----------------------- متوازيان لايمكن التقاطع
  if (bDotDPerp == 0)
    return false;

  Coords c = Coords(*b1); c.substract(a1);

  float t = ((long)c.getX() * d.getY() - (long)c.getY() * d.getX()) / bDotDPerp;  //-----------------------------------> float
  if (t < 0 || t > 1)
    return false;

  float u = ((long)c.getX() * b.getY() - (long)c.getY() * b.getX()) / bDotDPerp;
  if (u < 0 || u > 1)
    return false;

  return true; 
}

// a1 is line1 start, a2 is line1 end, b1 is line2 start, b2 is line2 end ------------------------------------------------------------> ننقص كل نهاية خط من بدايته
bool MapGraph::whereIntersects(Coords *a1, Coords *a2, Coords *b1, Coords *b2, Coords *intersection) {
  Coords b = Coords(*a2); b.substract(a1);
  Coords d = Coords(*b2); d.substract(b1);
  float bDotDPerp = (long)b.getX() * d.getY() - (long)b.getY() * d.getX();

  // if b dot d == 0, it means the lines are parallel so have infinite intersection points ------------------------------------------ لايمكن تقاطعها اذا تحقق يساوي صفر
  if (bDotDPerp == 0)
    return false;

  Coords c = Coords(*b1); c.substract(a1);

  float t = ((long)c.getX() * d.getY() - (long)c.getY() * d.getX()) / bDotDPerp;
  if (t < 0 || t > 1)
    return false;

  float u = ((long)c.getX() * b.getY() - (long)c.getY() * b.getX()) / bDotDPerp;
  if (u < 0 || u > 1)
    return false;

  // intersection = a1 + t * b;      -----------------------------------------------------------------  t  =   look at line 177+181
  intersection->setXY(a1->getX(), a1->getY());
  Coords tb = Coords(b);
  tb.setXY(t*b.getX(), t*b.getY());
  intersection->add(&tb);

  return true; 
}

