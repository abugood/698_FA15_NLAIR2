
#include "Processor.h"

Coords wayPoints[MAX_ROUTE_WPS];
unsigned char routeLength = 0;
unsigned long lastSpeedCheck;
float lastTraveledDist;

unsigned long lastDistanceCheck;

// Globals
float leftMotorPower;
float rightMotorPower;
// counters ----------------------------------------------------------------------- افهم المقصود ب اكستيرن
extern unsigned long leftCounter;
extern unsigned long rightCounter;

/**
 * Recaulculate the route from current position to the exit -------------------------------------------------------------  اعادة حسابات المسار الى الهدف
 * 
 */
void Processor::setup(WorldMap *wmap, SensedWorld *sensedWorld) {
	// Solve the graph ------------------------------------------------------------------------- يتم استدعاء هذه من صفحة mapgraph.cpp line 59
	wmap->mapGraph.solve(EXIT_NODE, ROBOT_NODE);

	// Now traverse the path, getting each Vertex in the Path as a new Waypoint -------------------------------------------جميع الزوايا  ستكون دلالات ع الطريق يستخدمها كنقطة تتبع جديدة
	int wpIndex = 0; // waypoint
	unsigned char *path = wmap->mapGraph.getPath();
	unsigned char n = ROBOT_NODE;

	// The origin point does not need to be in route, but we must set in SensedWorld    -------------------------------- النقطقة الرئيسية مو شرط تكون بالمسار ولكن لازم تنشأ في senseworld
	Coords robotPosition = wmap->vectorMap.getMapVertex(n);
	sensedWorld->xCmPos = robotPosition.getX(); //                     ---------- X
	sensedWorld->yCmPos = robotPosition.getY(); //                     -----------Y
	n = path[n];
//  defination -----------------------------------------------------------------------------------------------لازم تعرف ال إن    ايش يعمل هو نقطة مكان الروبوت
	while (n>0) {
		doLog(F("Route vertex: "));
		doLog(n);
		doLog(F(" ("));
		doLog(wmap->vectorMap.getMapVertex(n).getX());
		doLog(F(","));
		doLog(wmap->vectorMap.getMapVertex(n).getY());
		doLog(F(").\n"));

		wayPoints[wpIndex] = wmap->vectorMap.getMapVertex(n);
		n = path[n];
		wpIndex++;
	}

	// Finally add the exit as the last waypoint 
	wayPoints[wpIndex] = wmap->vectorMap.getMapVertex(n);
	wpIndex++;

	routeLength = wpIndex;  //   we save wpindex   ---------------------------------------------------داخل راوت لينقث اللي قيمته الابتدائية صفر سطر 5
}

/**
 * This method is used to execute one single hop  ---------------------------------------------------------------هذه الدالة  عملها  هو تنفيذ كل قفزة او نقله للروبوت وترجع اما صح او خطا
 * 
 * returns boolean, true if hop finished and the state should be changed---------------------------------------- اذا صح  معناها خلص  انتقل للمرحلة اللي بعدها
 */
bool Processor::doRun(SensedWorld *sensedWorld, WorldMap *wMap, Motion *motion) {
  Serial.println ("onehop \n\n");

	// Get the coordinates and orientation of robot
	// Coordinates do not change during the hop
	// Instead, the hop micromovement is stored in sensedWorld->xCmDelta and sensedWorld->yCmDelta-------------------------------احداثيات س و ص الحالية بعد التحرك   راجع سنس وورلد.اتش
 
	Coords rp = Coords(sensedWorld->xCmPos, sensedWorld->yCmPos);
	float ro_sd = Vector::to_other_degrees(sensedWorld->bearingDeg);
  
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Calculates the speed vector required to get to----------------------------------------- لازم نفهم كيف يحسب السرعة المطلوبة للحصول على النقطة التالية من مكانننا
	// next waypoint from current position
	// In WorldMap cm coordinates- ----------------------------------------------------------- بالسنتي
  
	Vector reqSpeed;
	{
		Coords diff = wayPoints[0];
		diff.substract(&rp);
		reqSpeed = Vector(&diff);
	}
// encoder counter ---------------------------------------------------------------------------------------------------------- اتوقع الانكودر يحسب لليمين واليسار 
	float traveledDist = ((float)leftCounter + rightCounter) / 2 * CM_PER_SLOT; // -------------------------------------------- defined وين عرفناه 

	// We calculate an estimation of speed here.
	// Also, update the distance delta for this hop

	unsigned long now = millis();
	if (now-lastSpeedCheck > SPEED_CHECK_INTERVAL) {
		float distDelta = traveledDist - lastTraveledDist; //            diff يعتبر عامل الفرق بين المسافتين
		if (distDelta < 0) {
			// There has been a counter reset in between ---------------------------------------------------------------------من سطر 85-90 لازم تفهم كيف يتم حساب السرعةوفيه ري سيت  بينهم
			distDelta = traveledDist;
		}
		sensedWorld->instantSpeed = ((double)distDelta) / SPEED_CHECK_INTERVAL * 1000.;
		lastTraveledDist = traveledDist;
		lastSpeedCheck = now;

		// Annotate last partial hop
		Vector vp = Vector(distDelta, ro_sd); // ------------------------------- here  راجع السطر 67 عشان ro_sd
		sensedWorld->xCmDelta += vp.getX();  // -------------------------------- Coords  احداثي ال س وال ص الحاليين بعد التحرك
		sensedWorld->yCmDelta += vp.getY();
	}
// --------------------------------------------------------------------------------------------------------------------------------------------------------
	// If the traveled distance bigger than requested, wayPoint reached
	// Calculate route and get next wayPoint, if not reached last waypoint
	// Compare with the most frequently updated data: traveledDist
	if (reqSpeed.rho - traveledDist < 1) {              // here -------------------------------------- راجع فيكتور .cpp سطر 13-15  و و .اتش سطر 12
		// Annotate last hop as traveled
		sensedWorld->xCmPos += sensedWorld->xCmDelta;  //  the real  ----------------------------------- الموقع للروبوت وزود عليه  الدلتا  وهو المسافة بعد التحرك
		sensedWorld->yCmPos += sensedWorld->yCmDelta;

		// Continue route ------------------------------------------------------------------------------ يكمل سيره بالمسارحتى يصل يزود i++
		if (routeLength>1) {
			for(int i=0; i<routeLength; i++) {
				wayPoints[i] = wayPoints[i+1];
			}
		}
		routeLength--;

		// At this point we need to start a "turning" sequence
		// this state machine is implemented in the main loop
		return true;
	}
  // ------------------------------------------------------------------------------------------------------------------------------------------------------------- 
	// Adjust speed, only modulus changes  -------------------------------------------------------------------------- المعامل اللي يتغير فقط 
	if (reqSpeed.rho > 0) {
		reqSpeed.rho = RUN_BASE_SPEED; // Fixed speed until stop. Related to PID KP value = common teqni used to control wide varity of the navigation

		// Works .....if speed in last time slice was too high, reduce base speed this time-----------------------------------طريقة ممتازة للتبديل بالسرعة
		if (sensedWorld->instantSpeed > 50) {          //  here  -------------------------------------------------------------راجع سطر 92 وشوف قيمة 
			reqSpeed.rho = RUN_BASE_SPEED * 0.33;
		} else if (sensedWorld->instantSpeed > 40) {
			reqSpeed.rho = RUN_BASE_SPEED * 0.50;
		} else if (sensedWorld->instantSpeed > 30) {
			reqSpeed.rho = RUN_BASE_SPEED * 0.66;
		}
	}

	// Now calculate desired speed
	// Only the angle is changed
	// Remember that the Vector maths is done in Standard degrees!--------------------------------------------------------------------- راجع صفحة ال فيكتور.cpp
	Vector errSpeed = reqSpeed;
	float errorAngle = Coords::normalizeAngle(reqSpeed.theta - ro_sd);   // -----------------------------------------------------------here راجع فيكتور .cpp سطر 31
	if (errorAngle > 180) errorAngle -= 360;  // Error will be in the range (-180, 180]
	errSpeed.theta = errorAngle;

	motion->setSpeeds(&reqSpeed, &errSpeed);

	return false;
}

/**
 * Initialization                                 --------------------------------------------------------------------------كونستركتور يحوي قيم ابتدائية
 */
void Processor::prepareToRun(SensedWorld *sensedWorld) {
	sensedWorld->xCmDelta = 0;
	sensedWorld->yCmDelta = 0;
}

/**
 * return target bearing angle in compass degree. ALWAYS POSITIVE, [0,360)
 */
float Processor::prepareToTurn(SensedWorld *sensedWorld) {

	// If the route is complete, stop
	if (routeLength<=0) {
		for(;;);               // -----------------------------------------------------   if its out of scope
	}

	// Obtain now the degrees to turn to head towards the new bearing
	Coords rp = Coords(sensedWorld->xCmPos, sensedWorld->yCmPos);
	Coords destPoint = wayPoints[0];  // Destination point is always the first point in the list.
	destPoint.substract(&rp);
	Vector reqSpeed = Vector(&destPoint);

	float targetBearing = Vector::to_other_degrees(reqSpeed.theta);
	targetBearing = Coords::normalizeAngle(targetBearing);

	return targetBearing;
}

/** ===========================================================================***=======================***===========================================================================
 *  
 * The check can be done frequently. For instance, to detect unexpected
 * obstacles, or to detect abnormal deviation.
 * If we detect an obstacle, or an abnormal deviation, we will END current run,------------------------------------------- اذا لاحظنا وجود عائق او او انحراف غير طبيعي  سننهي الحركة
 * apply corrective measure and continue. -------------------------------------------------------------------------------- يشيك ثم يعاود الحركة مرة اخرى 
 * CHECK:
 * But applying corrective measures will be done only after a Hop run ends,
 * and before starting the turn towards next waypoint
 *
 * Returns true if obstacle detected, or off track -------------------------------------------- يرجع نعم اذا حصل عايق او يتوقف 
 */
bool Processor::doDistanceChecks(WorldMap *wmap, SensedWorld *sensedWorld) {
	bool retVal = false;
	unsigned long now = millis();
	if (now-lastDistanceCheck > DISTANCE_CHECK_INTERVAL) {
		// 1. First calculate the theoretical distances from robot to Front, Left, Right and AFT ------------------------------------------------------------بداية 3 خطوات مهمه جدا او 4 خطوات
		// Get the coordinates and orientation of robot
		Coords rp = Coords(sensedWorld->xCmPos + sensedWorld->xCmDelta, sensedWorld->yCmPos +sensedWorld->yCmDelta);
		float ro_sd = Vector::to_other_degrees(sensedWorld->bearingDeg);
		float ro_rad = ro_sd * M_PI/180.;

		Coords b;
		// 1.1. Obtain FRONT Segment
		int x2 = rp.getX() + MAX_DISTANCE * cos(ro_rad);
		int y2 = rp.getY() + MAX_DISTANCE * sin(ro_rad);
		b = Coords(x2, y2);
		// Get distance to the closest Edge towards FRONT    ----------------------------------------------------ياخذ المسافة الى الحافة الاقرب امامه
		int dF = wmap->mapGraph.getClosestIntersection(&rp, &b);   // ----------------------see line  205 and 197

		// 1.2. Obtain LEFT Segment ------------------------------------------------------------------------------
		ro_rad += M_PI/2.;
		if(ro_rad > 2*M_PI) ro_rad -= 2.*M_PI;
		x2 = rp.getX() + MAX_DISTANCE * cos(ro_rad);
		y2 = rp.getY() + MAX_DISTANCE * sin(ro_rad);
		b = Coords(x2, y2);
		// Get distance to the closest Edge towards LEFT  -------------------------------------------------------ياخذ المسافة الى الحافة الاقرب عن يساره
		int dL = wmap->mapGraph.getClosestIntersection(&rp, &b);

		// 1.3. Obtain RIGHT Segment --------------------------------------------------------------------------------
		ro_rad += M_PI;
		if(ro_rad > 2*M_PI) ro_rad -= 2.*M_PI;
		x2 = rp.getX() + MAX_DISTANCE * cos(ro_rad);
		y2 = rp.getY() + MAX_DISTANCE * sin(ro_rad);
		b = Coords(x2, y2);
		// Get distance to the closest Edge towards RIGHT   -------------------------------------------------------ياخذ المسافة الاقرب الى الحافة عن يمينه
		int dR = wmap->mapGraph.getClosestIntersection(&rp, &b);

		// 2. Now check last read sonar distances ---------------------------------------------------------------خطوة 2 يحمل قيمه  اخر قراءات لكل ال 3 سناسر
		int sF = sensedWorld->freeSpace[0];
		int sL = sensedWorld->freeSpace[1];
		int sR = sensedWorld->freeSpace[2];

		// 3. Check new obstacle in front -------------------------------------------------------------------------------------- شرح العائق في الامام خطوة 3
		// If the free distance in front is LOWER than 30cm
		// AND the distance to the closest Edge towards FRONT   ------------------------اذا قدامك عايق اقل من 30سم اعتبره عايق جديد 
		// is GREATER than 30cm, consider it a NEW OBSTACLE.
		sensedWorld->obstacleFound = false;
		if (sF > 0 && sF < 30 && dF > 30) {     // ----------------------------------------------------see line 207
			sensedWorld->freeSpace[0] = 0;	// To be sure that old measure does not mistake us
			// It is an obtacle!
			sensedWorld->obstacleFound = true;
			// set robot node in wmap->vectorMap, with last hop as traveled
			wmap->vectorMap.setMapVertex(ROBOT_NODE, rp);
			// Also update robot position on wmap.
			sensedWorld->xCmPos += sensedWorld->xCmDelta;
			sensedWorld->yCmPos += sensedWorld->yCmDelta;
			// Reset hop deltas to avoid glitches
			sensedWorld->xCmDelta = 0; sensedWorld->yCmDelta = 0;
			retVal = true;
		} else {
			// 4. Now integrate all three deviations -------------------------------------------------------------------------خطوة 4 اعمل تكامل للانحرافات ال3وتوقع المسافة
			// An estimated distance < 0 means "distance > 4 meters" // yes  --------------------------------------اذا موقعه اصغر من صفر  معناها ماهو جوا الخريطه
			// dF is a positive deviation
     
			int dLXL = 0, dLXR = 0, dLX = 0, dLY = 0;
			if (dF>0) dLY += (dF-sF);  // yes   ----------------اذا المسافة قدام اكبر من صفر يصير الاجمالي ناقص اخر قراءة مسجلة للحساس الامامي 
			if (dR>0) dLXR = (dR-sR);  // yes   ----------------اذا المسافة يمين اكبر من صفر يصير الاجمالي ناقص اخر قراءة للحساس الايمن
			if (dL>0) dLXL = (dL-sL);  // yes   ----------------اذا المسافة يسار اكبر من صفر يصير الاجمالي المقروء ناقص اخر قراءة للحساس الايسر
			dLX = (dLXR + dLXL) / 2;

			// Check the magnitude of the deviation ----------------------------------- التحقق من حجم الانحراف
			// If big enough, take action to correct
			// Consider a deviation > 5cm big enough  --------------------------------- اذا شاطح 5 سم  لازم يصحح موقعه
			Coords deviation = Coords(dLX, dLY);
			Vector vDev = Vector(&deviation);

			if ( vDev.rho > 5) {
				// Translate deviation to world's coordinate system
				// Rotate to compensate bearing
				vDev.rotateDeg(90 - ro_sd);

				// Add the deviation to the current position with hop traveled
				rp.setXY(rp.getX() + vDev.getX(), rp.getY() + vDev.getY());

				// set robot node in wmap->vectorMap, in fixed position
				wmap->vectorMap.setMapVertex(ROBOT_NODE, rp);

				retVal = true;
			}
		}

		lastDistanceCheck = now;
	}

	return retVal;
}

/**
 * From current robot position, adds a new obstacle,
 * four vertices and four edges, to the map.
 * The physical obstacle will be surrounded by a security area
 * of 30 cm around. We will suppose that the obstacle is always 30cm x 30cm----------------------------اذا حصل عايق جديد يعتبر مساحته 30*30 ويحيطه بمنطقه عازله 30 سم من كل جهه
 * When we add the security area that makes 90cm side -------------------------------------------- ليصبح اجمالي مربع العايق 90*90 سم
 *
 * TODO: when we are low of memory, stop and blink leds.--------------------------------------------------------------------------------- اذا عندنا مشكلة بالميموري اللمبة تأشر
 *
 */
#define OBS_DIM 90   // ----------------------------------------------------------------------------------------variable  لازم تفهم ليش هالمتغير زاوية 90
void Processor::addObstacle(WorldMap *wmap, SensedWorld *sensedWorld ) {
	float rotation = Vector::to_other_degrees(sensedWorld->bearingDeg);
	Vector v;
	Coords rp = Coords(sensedWorld->xCmPos, sensedWorld->yCmPos);

	// Center of the box: the current robot position + 60cm + 15cm
	// along the bearing line
	Coords center = Coords(75, 0);// -------------------------------------------------------------------------------------------here لازم تفهم هالارقام
	// Rotate  ------------------------------------------عملية الالتفاف والدوران لكل زاويةمنتصف ولها معدل الدوران يعني الزاوية ولها الى الاحداثي  يعني اذا 4 زوايا *3 حالات = 12 حالة
	v = Vector(&center);
	v.rotateDeg(rotation);
	v.toCoords(&center);
	// Translate the center
	center.add(&rp);

	// Vertices  -------------------------------------------------------------------نفس طريقة اكواد حدود الخريطة بصفحة worldmap.cpp
 
  // Walls Vertices ------------------------------------------------------------ كانت 2*4 والان 2*2 غير هنا حسب حجم الخريطه الان 1 في 1     كمثال فقط يمكن تغييرها 
  //vectorMap.addMapVertex(Coords(0, 0));   // #2
  //vectorMap.addMapVertex(Coords(0, 100)); // #3
  //vectorMap.addMapVertex(Coords(100, 100)); // #4
  //vectorMap.addMapVertex(Coords(100, 0)); // #5

	Coords v1 = Coords(-OBS_DIM/2, -OBS_DIM/2);
	Coords v2 = Coords(-OBS_DIM/2, +OBS_DIM/2);
	Coords v3 = Coords(+OBS_DIM/2, +OBS_DIM/2);
	Coords v4 = Coords(+OBS_DIM/2, -OBS_DIM/2);

	// Rotate the obstacle "bearing" degree (in standard degree) around the center 0,0
  //------------------------------------------------------First Vertices
	v = Vector(&v1);
	v.rotateDeg(rotation);
	v.toCoords(&v1);
  //------------------------------------------------------Second Vertices
	v = Vector(&v2);
	v.rotateDeg(rotation);
	v.toCoords(&v2);
  //------------------------------------------------------Third Vertices
	v = Vector(&v3);
	v.rotateDeg(rotation);
	v.toCoords(&v3);
  //------------------------------------------------------4th Vertices
	v = Vector(&v4);
	v.rotateDeg(rotation);
	v.toCoords(&v4);

	// Now translate the obstacle to the center
	v1.add(&center);
	v2.add(&center);
	v3.add(&center);
	v4.add(&center);

	// Add the new vertices to the Map  ---------------------------------------------------addMapVertex---see vectormap.cpp line 16 was defined
	unsigned char v1N = wmap->vectorMap.addMapVertex(v1) - 1;
	unsigned char v2N = wmap->vectorMap.addMapVertex(v2) - 1;
	unsigned char v3N = wmap->vectorMap.addMapVertex(v3) - 1;
	unsigned char v4N = wmap->vectorMap.addMapVertex(v4) - 1;

	// Finally add the edges
	wmap->vectorMap.addMapEdge(v1N, v2N);
	wmap->vectorMap.addMapEdge(v2N, v3N);
	wmap->vectorMap.addMapEdge(v3N, v4N);
	wmap->vectorMap.addMapEdge(v4N, v1N);

 // as similar to this 
 // Walls Edges    ---------------------------see -worldmap.cpp------------------نقاط التلاقي بين الجدران لخريطه مربعه وومكن اضيف الخريطة للسيب
 // vectorMap.addMapEdge(2, 3);
 // vectorMap.addMapEdge(3, 4);
 // vectorMap.addMapEdge(4, 5);
 //vectorMap.addMapEdge(5, 2);


	doLog(F("Added four new vertices."));
	doLog(F("(")); doLog(v1.getX()); doLog(F(",")); doLog(v1.getY()); doLog(F(")"));
	doLog(F("(")); doLog(v2.getX()); doLog(F(",")); doLog(v2.getY()); doLog(F(")"));
	doLog(F("(")); doLog(v3.getX()); doLog(F(",")); doLog(v3.getY()); doLog(F(")"));
	doLog(F("(")); doLog(v4.getX()); doLog(F(",")); doLog(v4.getY()); doLog(F(")"));
	doLog(F("\n"));
}
