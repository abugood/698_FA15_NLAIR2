#include "VectorMap.h"

void VectorMap::clearMap() {
	nVertices = 0;
	nEdges = 0;
}

unsigned char VectorMap::getNVertices() {   //-----------------------------------------here: توضح عدد الزوايا بالخريطة 
	return nVertices;
}

unsigned char VectorMap::getNEdges() {     // -----------------------------------------here:  توضح عدد الحواف بالخريطة
	return nEdges;
}

unsigned char VectorMap::addMapVertex(Coords coords) {
	setMapVertex(nVertices++, coords);
	return nVertices;
}
// ---------------------------------------------------------------------------------------------here  يجيب احداثيات الزاوية
void VectorMap::setMapVertex(unsigned char index, Coords coords) {
 
	mapVertices[index][0] = coords.getX();
	mapVertices[index][1] = coords.getY();
   Serial.print("Map Vertices Index:");
  Serial.println(index);
  Serial.print("X,Y");
  Serial.print(mapVertices[index][0]);
  Serial.print(",");
  Serial.print(mapVertices[index][1]);
}

Coords VectorMap::getMapVertex(unsigned char index) {
	return Coords(mapVertices[index][0], mapVertices[index][1]);
}
// ---------------------------------------------------------------------------------------------here   مابين الزاويتين يمثل جدار ادج

unsigned char VectorMap::addMapEdge(unsigned char v1Index, unsigned int v2Index) {
	setMapEdge(nEdges++, v1Index, v2Index);
	return nEdges;
}

void VectorMap::setMapEdge(unsigned char index, unsigned char v1Index, unsigned int v2Index) {
	mapEdges[index][0] = v1Index;
	mapEdges[index][1] = v2Index;
}

unsigned char *VectorMap::getMapEdge(unsigned char index) {
	return mapEdges[index];
}

