

#ifndef COORDS_H_
#define COORDS_H_

#include "common.h"

class Coords {
private:
  int x;
  int y;
  
public:
	Coords(int x = 0, int y = 0);
	void setXY(int x, int y);
	int getX();
	int getY();
	int getTileX();
	int getTileY();
	float modulus();
	float angle();
	boolean equals(Coords *);
	void add(Coords *);
	void substract(Coords *);

 float static normalizeAngle(float);
};

#endif /* COORDS_H_ */

