// SensedWorld.cpp
// here ------------------------------------------------------------------------------هذه الصفحة تاخذ كل مدخلاتها من صفحة  سنسور.اتش و.سي بي بي  بواسطة انواع السناسر بوصلة انكودر وسونار
#include "SensedWorld.h"

SensedWorld::SensedWorld() {
	bearingDeg = 0;		// In compass degrees
	timeTag = 0;
	timeSlices = 0;
	xCmPos = 0;
	yCmPos = 0;
	obstacleFound = false;
	instantSpeed = 0.;
}

float SensedWorld::getBearingDeg() {
	return bearingDeg;
}

void SensedWorld::updateTimeTag() {
	timeTag = getCurrentTimeTag();
	timeSlices++;
}

unsigned long SensedWorld::getCurrentTimeTag() {
	return micros();
}

void SensedWorld::setFreeSpace(Byte direction, float cm) {
	freeSpace[direction] = cm;
}
