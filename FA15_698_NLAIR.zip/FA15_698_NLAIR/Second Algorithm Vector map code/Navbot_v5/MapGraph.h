#ifndef MAPGRAPH_H_
#define MAPGRAPH_H_

#include "limits.h"
#include "Coords.h"
#include "VectorMap.h"
#include "common.h"

class MapGraph {
private:
	VectorMap *vectorMap;
 
	unsigned int graphEdges[MAX_VERTEX_NUMBER*(MAX_VERTEX_NUMBER+1)/2]; //--------------------------------------------------------- *******
 
	int minDistance(unsigned int dist[], bool sptSet[], int vertices); // ------------------------------------------------------------------------------------------------------------***

	// The output array. dist[i] will hold the shortest distance from src to any i----------------------------------------------------------****************
	unsigned int dist[MAX_VERTEX_NUMBER];

	// ----------------------------------------------------------------------------------sptSet[i] will true if vertex i is included in shortest
	// ----------------------------------------------------------------------------------path tree or shortest distance from src to i is finalized

  
	bool sptSet[MAX_VERTEX_NUMBER];

	// References to previous node of each one.
	unsigned char prev[MAX_VERTEX_NUMBER-1];

	bool checkConnectionIntersections(int i, int j, int edges);
	bool intersects(Coords *a1, Coords *a2, Coords *b1, Coords *b2);
	bool whereIntersects(Coords *a1, Coords *a2, Coords *b1, Coords *b2, Coords *intersect);

public:
	MapGraph();
	MapGraph(VectorMap *vectorMap);
	void setEdge(unsigned char v1, unsigned char v2, unsigned int distance);
	unsigned int getEdge(unsigned char v1, unsigned char v2);
	void generateGraphFromMap();
  
	unsigned int solve(int src, int dest);  //--------------------------------------------------------------------------------------------------------------------------------------***
  
	unsigned char *getPath();
	int getClosestIntersection(Coords *a1, Coords *a2); // --------------------------------------------------------------------------------get Closest Intersection ----------------***
};

#endif
